#!/bin/bash

# 设置颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'

echo -e "${GREEN}[INFO]${NC} 开始部署..."

# 检查 Docker 是否安装
if ! command -v docker &> /dev/null; then
    echo -e "${RED}[ERROR]${NC} Docker 未安装，请先安装 Docker"
    exit 1
fi

# 检查 Docker Compose 是否安装
if ! command -v docker-compose &> /dev/null; then
    echo -e "${RED}[ERROR]${NC} Docker Compose 未安装，请先安装 Docker Compose"
    exit 1
fi

# 检查宿主机的 MySQL 和 Redis 是否运行
if ! systemctl is-active --quiet mysql; then
    echo -e "${RED}[ERROR]${NC} MySQL 服务未运行，请先启动 MySQL"
    exit 1
fi

if ! systemctl is-active --quiet redis; then
    echo -e "${RED}[ERROR]${NC} Redis 服务未运行，请先启动 Redis"
    exit 1
fi

# 停止并删除旧容器
docker-compose down

# 启动新容器
docker-compose up -d

# 检查容器是否成功启动
if [ $? -eq 0 ]; then
    echo -e "${GREEN}[INFO]${NC} 部署完成！"
    echo -e "${GREEN}[INFO]${NC} 服务运行在端口 6600"
else
    echo -e "${RED}[ERROR]${NC} 部署失败，请检查日志"
    exit 1
fi
